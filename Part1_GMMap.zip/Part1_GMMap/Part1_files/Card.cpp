#pragma once
#include "Card.h"

Card::Card(int cardID)
{
	id = cardID;
}
