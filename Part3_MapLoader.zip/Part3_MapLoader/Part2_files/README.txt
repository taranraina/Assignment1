-----------------------------------------------
Assignment 1 Part 3
-----------------------------------------------

// All functions and its attributes can be tested by commenting and uncommenting.

// Required files:
#include"Node.h"
#include"VGMap.h"
#include"BGMapLoader.h"
#include"VGMapLoader.h"
Boardmap.map
Villagemap.map

// Both Boardmap and Villagemap is loaded from Boardmap.map file and VGBoard.map file
// The driver will load a valid game and player board.
// Each tile with its id and adjacent information will be displayed
// Adjust console size by right clicking on the top of the console , click on properties and change layout 
// to Screen Buffer Size of height 1000. This will display all of the information.

